export  const categories = [
  'Mobiles', 'Laptops', 'Headphones', 'Watches', 'Cameras', 
  'Tablets', 'Gaming', 'Home', 'Fashion', 'Books'
];

export const products = {
  Mobiles: [
    { id: 1, name: 'iPhone 15 Pro', price: 999, image: 'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=300' },
    { id: 2, name: 'Samsung Galaxy S24', price: 899, image: 'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=300' },
    { id: 3, name: 'Google Pixel 8', price: 699, image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300' },
    { id: 4, name: 'OnePlus 12', price: 799, image: 'https://images.unsplash.com/photo-1598300042247-d088f8ab3a91?w=300' },
    { id: 5, name: 'Xiaomi 14', price: 599, image: 'https://images.unsplash.com/photo-1567581935884-3349723552ca?w=300' },
    { id: 6, name: 'iPhone 14', price: 799, image: 'https://images.unsplash.com/photo-1580910051074-3eb694886505?w=300' },
    { id: 7, name: 'Galaxy Note 23', price: 1099, image: 'https://images.unsplash.com/photo-1556656793-08538906a9f8?w=300' },
    { id: 8, name: 'Realme GT 6', price: 449, image: 'https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?w=300' },
    { id: 9, name: 'Oppo Find X7', price: 549, image: 'https://images.unsplash.com/photo-1607853202273-797f1c22a38e?w=300' },
    { id: 10, name: 'Vivo V30', price: 399, image: 'https://images.unsplash.com/photo-1601784551446-20c9e07cdbdb?w=300' }
  ],
  Laptops: [
    { id: 11, name: 'MacBook Pro M3', price: 1999, image: 'https://images.unsplash.com/photo-1541807084-5c52b6b3adef?w=300' },
    { id: 12, name: 'Dell XPS 13', price: 1299, image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=300' },
    { id: 13, name: 'ThinkPad X1', price: 1599, image: 'https://images.unsplash.com/photo-1484788984921-03950022c9ef?w=300' },
    { id: 14, name: 'HP Spectre x360', price: 1199, image: 'https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=300' },
    { id: 15, name: 'Asus ZenBook', price: 999, image: 'https://images.unsplash.com/photo-1525547719571-a2d4ac8945e2?w=300' },
    { id: 16, name: 'Surface Laptop 5', price: 1399, image: 'https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=300' },
    { id: 17, name: 'Acer Swift 3', price: 699, image: 'https://images.unsplash.com/photo-1531297484001-80022131f5a1?w=300' },
    { id: 18, name: 'Gaming Legion 7', price: 1899, image: 'https://images.unsplash.com/photo-1593642702821-c8da6771f0c6?w=300' },
    { id: 19, name: 'MacBook Air M2', price: 1199, image: 'https://images.unsplash.com/photo-1517180102446-f3ece451e9d8?w=300' },
    { id: 20, name: 'Chromebook Plus', price: 399, image: 'https://images.unsplash.com/photo-1587614387466-0a72ca909e16?w=300' }
  ],
  Headphones: [
    { id: 21, name: 'AirPods Pro 2', price: 249, image: 'https://images.unsplash.com/photo-1606220588913-b3aacb4d2f46?w=300' },
    { id: 22, name: 'Sony WH-1000XM5', price: 399, image: 'https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?w=300' },
    { id: 23, name: 'Bose QC45', price: 329, image: 'https://images.unsplash.com/photo-1583394838336-acd977736f90?w=300' },
    { id: 24, name: 'Beats Studio 3', price: 199, image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=300' },
    { id: 25, name: 'JBL Quantum 800', price: 149, image: 'https://images.unsplash.com/photo-1546435770-a3e426bf472b?w=300' },
    { id: 26, name: 'SteelSeries Arctis 7', price: 179, image: 'https://images.unsplash.com/photo-1484704849700-f032a568e944?w=300' },
    { id: 27, name: 'Sennheiser HD 660S', price: 499, image: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?w=300' },
    { id: 28, name: 'Audio-Technica ATH', price: 299, image: 'https://images.unsplash.com/photo-1558756520-22cfe5d382ca?w=300' },
    { id: 29, name: 'Razer BlackShark', price: 99, image: 'https://images.unsplash.com/photo-1577174881658-0f30ed549adc?w=300' },
    { id: 30, name: 'HyperX Cloud III', price: 129, image: 'https://images.unsplash.com/photo-1590658165737-15a047b7972d?w=300' }
  ],
  Watches: [
    { id: 31, name: 'Apple Watch Ultra 2', price: 799, image: 'https://images.unsplash.com/photo-1434493789847-2f02dc6ca35d?w=300' },
    { id: 32, name: 'Galaxy Watch 6', price: 329, image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=300' },
    { id: 33, name: 'Fitbit Sense 2', price: 299, image: 'https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=300' },
    { id: 34, name: 'Garmin Forerunner', price: 449, image: 'https://images.unsplash.com/photo-1617043983671-adaadcaa2460?w=300' },
    { id: 35, name: 'Fossil Gen 6', price: 255, image: 'https://images.unsplash.com/photo-1461141346587-763ab02bced9?w=300' },
    { id: 36, name: 'TAG Heuer Connected', price: 1199, image: 'https://images.unsplash.com/photo-1522312346375-d1a52e2b99b3?w=300' },
    { id: 37, name: 'Casio G-Shock', price: 129, image: 'https://images.unsplash.com/photo-1547996160-81dfa63595aa?w=300' },
    { id: 38, name: 'Amazfit GTR 4', price: 199, image: 'https://images.unsplash.com/photo-1609081219090-a6d81d3085bf?w=300' },
    { id: 39, name: 'Polar Pacer Pro', price: 349, image: 'https://images.unsplash.com/photo-1579586337278-3f436f25d4d6?w=300' },
    { id: 40, name: 'Suunto 9 Peak', price: 399, image: 'https://images.unsplash.com/photo-1606889464198-fcb18894cf55?w=300' }
  ],
  Cameras: [
    { id: 41, name: 'Canon EOS R5', price: 3899, image: 'https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=300' },
    { id: 42, name: 'Sony A7 IV', price: 2499, image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?w=300' },
    { id: 43, name: 'Nikon Z9', price: 5499, image: 'https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=300' },
    { id: 44, name: 'Fujifilm X-T5', price: 1699, image: 'https://images.unsplash.com/photo-1606983340126-99ab4feaa64a?w=300' },
    { id: 45, name: 'GoPro Hero 12', price: 399, image: 'https://images.unsplash.com/photo-1554844195-72d5c62ecd3e?w=300' },
    { id: 46, name: 'Olympus OM-1', price: 2199, image: 'https://images.unsplash.com/photo-1495121553079-4c61bcce1894?w=300' },
    { id: 47, name: 'Panasonic GH6', price: 2199, image: 'https://images.unsplash.com/photo-1471634711903-6754b15592df?w=300' },
    { id: 48, name: 'DJI Pocket 2', price: 449, image: 'https://images.unsplash.com/photo-1609010697446-11f2155278f0?w=300' },
    { id: 49, name: 'Canon PowerShot', price: 1299, image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300' },
    { id: 50, name: 'Leica Q2', price: 4995, image: 'https://images.unsplash.com/photo-1613767211022-6f0e06bf6d88?w=300' }
  ],
  Tablets: [
    { id: 51, name: 'iPad Pro 12.9', price: 1099, image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=300' },
    { id: 52, name: 'Galaxy Tab S9', price: 799, image: 'https://images.unsplash.com/photo-1593642632823-8f785ba67e45?w=300' },
    { id: 53, name: 'Surface Pro 9', price: 999, image: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=300' },
    { id: 54, name: 'iPad Air 5', price: 599, image: 'https://images.unsplash.com/photo-1585790050230-5dd28404ccb9?w=300' },
    { id: 55, name: 'Xiaomi Pad 6', price: 399, image: 'https://images.unsplash.com/photo-1607270434003-2f2b2d6a2cb9?w=300' },
    { id: 56, name: 'Amazon Fire HD', price: 149, image: 'https://images.unsplash.com/photo-1572635196237-14b3f281503f?w=300' },
    { id: 57, name: 'Lenovo Tab P11', price: 229, image: 'https://images.unsplash.com/photo-1605810230434-7631ac76ec81?w=300' },
    { id: 58, name: 'Huawei MatePad', price: 349, image: 'https://images.unsplash.com/photo-1553540059-7ad3e34624c7?w=300' },
    { id: 59, name: 'iPad Mini 6', price: 499, image: 'https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=300' },
    { id: 60, name: 'OnePlus Pad', price: 479, image: 'https://images.unsplash.com/photo-1588872657578-7efd1f1555ed?w=300' }
  ],
  Gaming: [
    { id: 61, name: 'PlayStation 5', price: 499, image: 'https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=300' },
    { id: 62, name: 'Xbox Series X', price: 499, image: 'https://images.unsplash.com/photo-1621259182978-fbf93132d53d?w=300' },
    { id: 63, name: 'Nintendo Switch', price: 299, image: 'https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=300' },
    { id: 64, name: 'Steam Deck', price: 399, image: 'https://images.unsplash.com/photo-1625842268584-8f3296236761?w=300' },
    { id: 65, name: 'RTX 4080 GPU', price: 1199, image: 'https://images.unsplash.com/photo-1591488320449-011701bb6704?w=300' },
    { id: 66, name: 'Gaming Chair Pro', price: 299, image: 'https://images.unsplash.com/photo-1592078615290-033ee584e267?w=300' },
    { id: 67, name: 'Mechanical Keyboard', price: 149, image: 'https://images.unsplash.com/photo-1587829741301-dc798b83add3?w=300' },
    { id: 68, name: 'Gaming Mouse', price: 79, image: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=300' },
    { id: 69, name: '4K Gaming Monitor', price: 699, image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?w=300' },
    { id: 70, name: 'VR Headset Meta', price: 499, image: 'https://images.unsplash.com/photo-1617802690992-15d93263d3a9?w=300' }
  ],
  Home: [
    { id: 71, name: 'Smart TV 65"', price: 899, image: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?w=300' },
    { id: 72, name: 'Echo Dot 5th Gen', price: 49, image: 'https://images.unsplash.com/photo-1518444065439-e933c06ce9cd?w=300' },
    { id: 73, name: 'Dyson V15 Vacuum', price: 749, image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=300' },
    { id: 74, name: 'Instant Pot Duo', price: 99, image: 'https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=300' },
    { id: 75, name: 'Philips Hue Lights', price: 199, image: 'https://images.unsplash.com/photo-1513506003901-1e6a229e2d15?w=300' },
    { id: 76, name: 'Nest Thermostat', price: 249, image: 'https://images.unsplash.com/photo-1582219788330-47d6c6c6de5b?w=300' },
    { id: 77, name: 'Ring Video Doorbell', price: 179, image: 'https://images.unsplash.com/photo-1558618047-3c8c76ca7d13?w=300' },
    { id: 78, name: 'Air Purifier', price: 299, image: 'https://images.unsplash.com/photo-1585829365295-ab7cd400c167?w=300' },
    { id: 79, name: 'Robot Vacuum', price: 399, image: 'https://images.unsplash.com/photo-1517705008128-361805f42e86?w=300' },
    { id: 80, name: 'Coffee Maker', price: 149, image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=300' }
  ],
  Fashion: [
    { id: 81, name: 'Designer Sneakers', price: 299, image: 'https://images.unsplash.com/photo-1549298916-b41d501d3772?w=300' },
    { id: 82, name: 'Leather Jacket', price: 199, image: 'https://images.unsplash.com/photo-1551028719-00167b16eac5?w=300' },
    { id: 83, name: 'Denim Jeans', price: 89, image: 'https://images.unsplash.com/photo-1542272604-787c3835535d?w=300' },
    { id: 84, name: 'Wool Sweater', price: 129, image: 'https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=300' },
    { id: 85, name: 'Summer Dress', price: 79, image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=300' },
    { id: 86, name: 'Running Shoes', price: 149, image: 'https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?w=300' },
    { id: 87, name: 'Handbag Designer', price: 249, image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=300' },
    { id: 88, name: 'Sunglasses', price: 159, image: 'https://images.unsplash.com/photo-1511499767150-a48a237f0083?w=300' },
    { id: 89, name: 'Winter Coat', price: 299, image: 'https://images.unsplash.com/photo-1544966503-7cc5ac882d5f?w=300' },
    { id: 90, name: 'Athletic Wear Set', price: 99, image: 'https://images.unsplash.com/photo-1506629905607-45cf593c8446?w=300' }
  ],
  Books: [
    { id: 91, name: 'Programming Guide', price: 49, image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300' },
    { id: 92, name: 'Design Thinking', price: 39, image: 'https://images.unsplash.com/photo-1481627834876-b7833e8f5570?w=300' },
    { id: 93, name: 'Business Strategy', price: 45, image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=300' },
    { id: 94, name: 'AI & Machine Learning', price: 59, image: 'https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?w=300' },
    { id: 95, name: 'Web Development', price: 42, image: 'https://images.unsplash.com/photo-1532012197267-da84d127e765?w=300' },
    { id: 96, name: 'Data Science', price: 55, image: 'https://images.unsplash.com/photo-1543002588-bfa74002ed7e?w=300' },
    { id: 97, name: 'Psychology Today', price: 29, image: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?w=300' },
    { id: 98, name: 'Marketing 101', price: 35, image: 'https://images.unsplash.com/photo-1589998059171-988d887df646?w=300' },
    { id: 99, name: 'Leadership Skills', price: 38, image: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=300' },
    { id: 100, name: 'Creative Writing', price: 32, image: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?w=300' }
  ]
};
 