# My Tasks App

**Developer:** Your Name

## 📱 Description
A simple React Native task management app built with Expo. Add, complete, delete tasks and get notified shortly after task creation.

## 🚀 Features
- Add new tasks
- Mark tasks as completed
- Delete tasks
- Local notifications (10s after task creation)
- Notification cancellation on completion
- Task persistence using AsyncStorage

## 🛠 Setup Instructions

1. Clone the repository or copy the folder.
2. Navigate into the folder:
   ```bash
   cd MyTasksApp
   ```
3. Install dependencies:
   ```bash
   npm install
   ```
4. Start the app:
   ```bash
   npx expo start
   ```

> Open in **Expo Go** (scan the QR code).

## 📌 Notes
- Ensure notifications are enabled on your device.
- Tasks persist even after closing the app.

## 🎯 Challenges
- Handling cancellation of scheduled notifications when tasks are marked complete.
- Managing persistent state with AsyncStorage.
